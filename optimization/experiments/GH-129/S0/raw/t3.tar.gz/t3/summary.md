| tier | code | mode | off wall s / conflicts / decisions | on wall ratio / confl ratio / dec ratio (picks %) | postsol wall ratio / confl ratio / dec ratio (picks %) | presol wall ratio / confl ratio / dec ratio (picks %) | answers |
|---|---|---|---|---|---|---|---|
| tier3 | BB_288_12_18 | card-mto | 401.71 / 3680505 / 4608311 | 0.218 / 0.195 / 0.216 (52%) | - | - | ok,ok |
| tier3 | BB_288_12_18 | no-card | 337.70 / 3057085 / 3818141 | 0.333 / 0.282 / 0.330 (49%) | - | - | ok,ok |
| tier3 | GB_144_12_12 | card-mto | 102.54 / 1669862 / 1935808 | 0.104 / 0.116 / 0.102 (99%) | - | - | ok,ok |
| tier3 | GB_144_12_12 | no-card | 66.22 / 1210887 / 1387391 | 0.402 / 0.364 / 0.322 (100%) | - | - | ok,ok |
| tier3 | LP_544_80_12 | card-mto | 51.32 / 384552 / 668348 | 0.375 / 0.249 / 0.214 (55%) | - | - | ok,ok |
| tier3 | LP_544_80_12 | no-card | 222.07 / 1420652 / 2223231 | 0.087 / 0.065 / 0.063 (54%) | - | - | ok,ok |
| tier3 | TN_144_2_13 | card-mto | 160.05 / 2391535 / 2682434 | 0.715 / 0.547 / 0.500 (98%) | - | - | ok,ok |
| tier3 | TN_144_2_13 | no-card | 71.64 / 1150798 / 1300524 | 1.610 / 1.139 / 1.026 (99%) | - | - | ok,ok |
| tier3 | TN_200_10_10 | card-mto | 10.67 / 187743 / 269308 | 0.892 / 0.573 / 0.582 (55%) | - | - | ok,ok |
| tier3 | TN_200_10_10 | no-card | 13.77 / 242100 / 326716 | 1.386 / 0.852 / 0.743 (76%) | - | - | ok,ok |

| tier | mode | arm | geomean wall ratio | geomean conflict ratio | max wall ratio | n |
|---|---|---|---|---|---|---|
| tier3 | card-mto | on | 0.352 | 0.281 | 0.892 | 5 |
| tier3 | no-card | on | 0.482 | 0.365 | 1.610 | 5 |
