#!/bin/bash
cd ~/mac-agent-20261009/gh129-d1f3f41
O=../gh129-s1/ident
codes=$(ls data/matrices/tier0 data/matrices/tier1 | grep _Hx.txt | sed s/_Hx.txt//)
core=64
for c in $codes; do t=$(ls -d data/matrices/tier*/${c}_Hx.txt | head -1 | cut -d/ -f3)
 for m in no-card card-mto; do
  for arm in main cand; do
   b=../frozen/server-gh129-d1f3f41/distqldpc; [ $arm = main ] && b=../frozen/server-main398/distqldpc
   taskset -c $core prlimit --as=4294967296 -- $b -v -cpu-lim=600 -$m data/matrices/$t/$c > $O/$c.$m.$arm.log 2>&1 &
   core=$((core+1)); if [ $core -gt 119 ]; then wait; core=64; fi
  done; done; done
wait
echo DONE
