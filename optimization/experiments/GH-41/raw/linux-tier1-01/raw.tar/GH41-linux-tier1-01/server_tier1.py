"""Disabled GH41 native Tier1. Frozen Tier0 binaries; no builds or auto advance."""
import argparse,hashlib,importlib.util,json,math,os,re,shutil,signal,statistics,sys
from pathlib import Path
ASSIGNED_URL='https://github.com/guluchen/DistQLDPC/issues/15#issuecomment-6069089234'
BASE='24572d6d09cce9a4a5faa58300a89e0feba9da6a'
CAND='66cf8be5a4881643f2063471325e33cecaa0caf1'
TIER0_MANIFEST_SHA='ecf1f127d1d6f130fa99d954220e10f70a8accec5b6d7d01de2b14ab1118deeb'
TIER0_AUDIT_SHA='c9fe629d492e50c9c94f6644390ce2fa47a309da8f92fc218f7b49e27b6a7d0d'
RUNTIME_SHA='940fce2a7063e8f6c3fce44fe1e013d194712a7ed9b05873dc2a89ad61accd8a'
HOSTED_AUDIT_SHA='87c45397e734dab37910c633a42db2e28cdb1474eef1570987a17b7a3c870481'
BINHASHES={'baseline':'13e15ba78f1d7f96af7d54ba767d3e99fb23c8cf44109b9610f037d343051cf4','candidate':'ba374320bc3c20679585bf8a552c374636404d26a45383bd7d40a0f79f436a03'}
HOSTED_ZIP_SHA='bc9bf45541d332dff2def2042c160c91cb9bce0bc9626d85ce79af2fa95bd33f'
HOSTED_MERGE='e87894a70b37e675c4c7f3d8a533f86d0f0c8208'
CASES=['BB_90_8_10','GB_144_12_8','BB_108_8_10','LP_238_44_6']
MODES=['no-card','card-mto']
POLICY='OBSERVED_QUIET_DIAGNOSTIC_FORMAL_INCONCLUSIVE'
ROBUSTNESS_PRERECORD_COMMIT='ab61a882cea88fdc689b1eaaa591e624b9eb3701'
ROBUSTNESS_PRERECORD_SHA='e5a81bcdaf65af5b2da91a5e89c59016780a93d04b5c8d14b8fba1cd56519ff0'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def incomplete_science(science,rc,text,exact):
    # Original application has two lawful incomplete trailers. Preserve both
    # verbatim; the frozen Tier0 parser deliberately tests true TIMEOUT only.
    statuses=re.findall(r'^s\s+(.*?)\s*$',text,re.M)
    comments=re.findall(r'^c status:\s*(.*?)\s*$',text,re.M)
    distance=re.findall(r'^c\s+d\s*:\s*(.*?)\s*$',text,re.M)
    science.need(rc==1 and statuses==['UNKNOWN'] and len(comments)==1 and
        comments[0] in ['UNKNOWN','TIMEOUT (child killed after -cpu-lim)'],'Incomplete status/return')
    science.need(distance==['UNKNOWN'] and not re.search(r'^o(?:\s|$)',text,re.M),'Incomplete fabricated/missing distance or objective')
    values={'d':None,'objective':None}
    for key in ['lb','ub']:
        raw=re.findall(r'^c\s+d_'+key+r':\s*(.*?)\s*$',text,re.M)
        science.need(bool(raw),'Missing incomplete '+key)
        for item in raw:
            if item=='-':continue
            science.need(re.fullmatch(r'\d+',item) is not None,'Malformed incomplete '+key)
            value=int(item);science.need(value<=exact if key=='lb' else value>=exact,'Wrong incomplete '+key)
        values[key]=int(raw[-1]) if re.fullmatch(r'\d+',raw[-1]) else None
    return dict(values,returncode=rc,timeout=comments[0].startswith('TIMEOUT'),reported_status=comments[0])
def host_configuration(cpu,sibling):
    paths=['/sys/devices/system/cpu/cpufreq/boost','/sys/devices/system/cpu/intel_pstate/no_turbo','/sys/devices/system/clocksource/clocksource0/current_clocksource']
    for number in [cpu,sibling]:
        paths += [f'/sys/devices/system/cpu/cpu{number}/cpufreq/'+name for name in ['scaling_governor','scaling_min_freq','scaling_max_freq']]
    result={}
    for name in paths:
        try:result[name]={'value':Path(name).read_text().strip(),'available':True}
        except FileNotFoundError:result[name]={'value':None,'available':False}
    return result
def robustness_details(samples,cases):
    details=[]
    for case in cases:
        for mode in MODES:
            rows={v:[r for r in samples if r['case']==case and r['mode']==mode and r['version']==v] for v in BINHASHES}
            intervals={v:[r['exit_interval_sec'] for r in rows[v]] for v in rows}
            cpu={v:[r['waited_child_cpu_sec'] for r in rows[v]] for v in rows}
            pairs=[]
            for repeat in range(1,4):
                b=next(r for r in rows['baseline'] if r['repeat']==repeat);c=next(r for r in rows['candidate'] if r['repeat']==repeat)
                pairs.append(dict(repeat=repeat,order=['baseline','candidate'] if repeat%2 else ['candidate','baseline'],
                    exit_interval_win=c['exit_interval_sec'][1]<b['exit_interval_sec'][0],cpu_win=c['waited_child_cpu_sec']<b['waited_child_cpu_sec'],
                    conservative_exit_difference_sec=c['exit_interval_sec'][1]-b['exit_interval_sec'][0],cpu_difference_sec=c['waited_child_cpu_sec']-b['waited_child_cpu_sec']))
            exit_win=max(x[1] for x in intervals['candidate'])<min(x[0] for x in intervals['baseline'])
            cpu_win=max(cpu['candidate'])<min(cpu['baseline'])
            details.append(dict(case=case,mode=mode,exit_intervals=intervals,cpu_raw=cpu,
                median_exit_intervals={v:[statistics.median(x[i] for x in intervals[v]) for i in [0,1]] for v in intervals},
                candidate_max_exit_upper=max(x[1] for x in intervals['candidate']),baseline_min_exit_lower=min(x[0] for x in intervals['baseline']),
                candidate_max_cpu=max(cpu['candidate']),baseline_min_cpu=min(cpu['baseline']),pairs=pairs,
                exit_ranges_disjoint_positive=exit_win,cpu_ranges_disjoint_positive=cpu_win,
                corroborated=exit_win and cpu_win and all(p['exit_interval_win'] and p['cpu_win'] for p in pairs)))
    return details
def judge(samples,cases):
    # Exact numeric-filter logic from authenticated E004 run.py judge().
    details=[]; modes={}
    for mode in MODES:
        median_ratios=[]; worst_ratios=[]; nonworse=True
        for case in cases:
            b=[r['elapsed_sec'] for r in samples if r['case']==case and r['mode']==mode and r['version']=='baseline']
            c=[r['elapsed_sec'] for r in samples if r['case']==case and r['mode']==mode and r['version']=='candidate']
            if len(b)!=3 or len(c)!=3:raise ValueError('incomplete samples')
            bm,cm=statistics.median(b),statistics.median(c)
            details.append({'case':case,'mode':mode,'baseline_raw':b,'candidate_raw':c,
                'baseline_median':bm,'candidate_median':cm,'median_ratio':cm/bm,
                'baseline_range_over_median':(max(b)-min(b))/bm,
                'baseline_min':min(b),'baseline_max':max(b),'candidate_min':min(c),'candidate_max':max(c)})
            if min(c)>max(b):return 'reject','confirmed per-case regression',details
            median_ratios.append(cm/bm);worst_ratios.append(max(c)/min(b));nonworse &= cm<=bm
        gm=lambda xs:math.exp(sum(math.log(x) for x in xs)/len(xs))
        modes[mode]={'median_geomean':gm(median_ratios),'range_envelope_geomean':gm(worst_ratios),'no_worse_medians':nonworse}
    passed=all(x['range_envelope_geomean']<1 and x['no_worse_medians'] for x in modes.values())
    return ('pass' if passed else 'inconclusive'),modes,details
def main():
    ap=argparse.ArgumentParser()
    for name in ['package','out','runtime-inventory','tier0','tier0-audit','hosted-audit','prerecord']:ap.add_argument('--'+name,type=Path,required=True)
    for name in ['run-assignment','manifest-sha','runtime-sha','support-sha','tier0-sha','tier0-audit-sha','hosted-audit-sha','prerecord-sha']:ap.add_argument('--'+name,required=True)
    ap.add_argument('--cpu',type=int,required=True);ap.add_argument('--sibling',type=int,required=True)
    a=ap.parse_args();assert ASSIGNED_URL!='HOST_SLOT_NOT_ASSIGNED' and a.run_assignment==ASSIGNED_URL
    assert 'NOT_FROZEN' not in ''.join([TIER0_MANIFEST_SHA,TIER0_AUDIT_SHA,RUNTIME_SHA,HOSTED_AUDIT_SHA,*BINHASHES.values()])
    assert sys.platform=='linux' and os.geteuid()!=0
    assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
    assert not any(os.environ.get(k) for k in ['CXX','CXXFLAGS','LDFLAGS','MAKEFLAGS','LD_PRELOAD','LD_LIBRARY_PATH'])
    package=a.package.resolve();t0=a.tier0.resolve();out=a.out.resolve()
    assert t0.parent==Path.home() and out.parent==Path.home() and not out.exists() and t0!=out
    assert not any(p.name=='__pycache__' or p.suffix=='.pyc' for p in package.rglob('*'))
    pins={};whole={}
    def pin(p,value):
        p=p.resolve();assert sha(p)==value,'Identity mismatch: '+str(p);pins[str(p)]=value
    pin(package/'manifest.json',a.manifest_sha);manifest=read(package/'manifest.json')
    assert manifest['support_head']==a.support_sha and manifest['baseline']==BASE and manifest['candidate']==CAND
    for name,value in manifest['files'].items():
        p=(package/name).resolve();assert p.is_relative_to(package);pin(p,value)
    assert sha(__file__)==manifest['files']['support/server_tier1.py']
    pin(package/'support/TIER1_NATIVE_ROBUSTNESS_PROPOSAL.md',ROBUSTNESS_PRERECORD_SHA)
    assert a.tier0_sha==TIER0_MANIFEST_SHA and a.tier0_audit_sha==TIER0_AUDIT_SHA
    pin(t0/'SHA256.json',a.tier0_sha);raw=read(t0/'SHA256.json')
    assert len(raw)>=200,'Incomplete native Tier0 evidence'
    for name,value in raw.items():
        p=(t0/name).resolve();assert p.is_relative_to(t0);assert sha(p)==value;whole[str(p)]=value
    pin(a.tier0_audit,a.tier0_audit_sha);audit=read(a.tier0_audit)
    assert audit['classification']=='GH41_NATIVE_TIER0_INDEPENDENT_AUDIT'
    assert audit['baseline']==BASE and audit['candidate']==CAND and audit['raw_manifest_sha']==TIER0_MANIFEST_SHA
    assert all(audit[k] is True for k in ['science_complete','full_raw_hashes_match','source_archives_match','runtime_input_binary_hashes_match','owned_empty','actual_restore','outer_transport_valid','full_boundary_identities'])
    assert audit['counts']=={'science':52,'PMS':162,'helper':21840}
    summary0=read(t0/'summary.json')
    assert summary0['status']=='TIER0_COMPLETE' and summary0['Tier0']=='LOCAL_PASS' and summary0['valid_run'] is True
    assert summary0['baseline']==BASE and summary0['candidate']==CAND
    assert summary0['science']==52 and summary0['PMS']==162 and summary0['helper']==21840
    assert summary0['identity_confirmed'] is True and summary0['cleanup_restoration_confirmed'] is True
    assert summary0['classification']=='CORRECTNESS_CAPACITY_ONLY' and summary0['performance']=='NOT_MEASURED'
    prior_context=read(t0/'context.json');assert prior_context['cpu']==a.cpu and prior_context['sibling']==a.sibling
    science0=read(t0/'science.json');pms0=read(t0/'pms-results.json')
    assert len(science0)==52 and len(pms0)==162 and read(t0/'full-runtime-postexecution.json')['confirmed'] is True
    assert a.runtime_sha==RUNTIME_SHA and sha(t0/'runtime-inventory.json')==RUNTIME_SHA
    pin(a.runtime_inventory,a.runtime_sha);runtime=read(a.runtime_inventory)
    assert runtime['schema_version']==2 and runtime['metadata_only'] is True and runtime['gcc_version'].split('.')[0]=='13'
    assert runtime['identity_policy']=='FULL_PRE_IMPORT_AND_POST_RUN_CRITICAL_PER_COMMAND'
    assert runtime['cache_policy']=='DONTWRITE_BYTECODE_FULL_PRE_POST_EXISTING_PYC'
    assert runtime['critical_files'] and all(runtime['files'].get(p)==v for p,v in runtime['critical_files'].items())
    assert str(Path(sys.executable).resolve())==runtime['python']
    for p,v in runtime['files'].items():assert sha(p)==v;whole[p]=v
    for p,v in runtime['critical_files'].items():pin(Path(p),v)
    assert a.hosted_audit_sha==HOSTED_AUDIT_SHA;pin(a.hosted_audit,a.hosted_audit_sha);hosted=read(a.hosted_audit)
    assert hosted['candidate']==CAND and hosted['executed_merge']==HOSTED_MERGE and hosted['zip_sha256']==HOSTED_ZIP_SHA
    assert hosted['final_science_count']==8 and all(hosted[k] is True for k in ['source_byte_equal','final_science_pass','original_zip_retained'])
    assert hosted['interim_bounds_retained'] is False and hosted['timing_classification']=='DIAGNOSTIC_ONLY'
    assert sha(Path(hosted['zip_path']))==HOSTED_ZIP_SHA;pin(Path(hosted['zip_path']),HOSTED_ZIP_SHA)
    pin(a.prerecord,a.prerecord_sha);prereg=read(a.prerecord)
    assert prereg['assignment']==a.run_assignment and prereg['support_head']==a.support_sha
    assert prereg['baseline']==BASE and prereg['candidate']==CAND and prereg['cases']==CASES and prereg['modes']==MODES
    assert prereg['repeats']==3 and prereg['order']==['baseline','candidate','candidate','baseline','baseline','candidate']
    assert prereg['internal_limit']==180 and prereg['outer_limit']==195 and prereg['aggregate_limit']==10800
    assert prereg['exclusive'] is False and prereg['interpretation']==POLICY and prereg['controlled_claim'] is False
    assert prereg['cpu']==a.cpu and prereg['sibling']==a.sibling and prereg['tier0_manifest_sha']==TIER0_MANIFEST_SHA
    assert prereg['robustness_prerecord_commit']==ROBUSTNESS_PRERECORD_COMMIT and prereg['robustness_prerecord_sha']==ROBUSTNESS_PRERECORD_SHA
    binaries={v:t0/v/'bin/distqldpc' for v in BINHASHES}
    assert read(t0/'binary-hashes.json')==BINHASHES
    for v,p in binaries.items():pin(p,BINHASHES[v])
    frozen=read(t0/'frozen-package/manifest.json')
    assert frozen['baseline']==BASE and frozen['candidate']==CAND
    for case in CASES:
        for suffix in ['Hx','Hz','Gx','Gz']:
            name=case+'_'+suffix+'.txt';value=frozen['files']['inputs/'+name]
            assert prereg['inputs'][name]==value
            pin(t0/'frozen-package/inputs'/name,value)
    # Entire original source + runtime + raw authenticated above. Per solve only
    # immutable code/support/input/binary/critical runtime, not old build logs.
    for name,value in raw.items():
        if name.startswith(('baseline/src/','candidate/src/','frozen-package/')) or name in ['baseline/Makefile','candidate/Makefile']:pins[str(t0/name)]=value
    supervisor=module('gh41_tier1_supervisor',package/'support/server_tier1_supervisor.py')
    science=module('gh41_tier1_science',t0/'frozen-package/support/server_science.py')
    assert supervisor.RUN_ASSIGNMENT==a.run_assignment
    def terminate(signum,frame):raise RuntimeError('External Tier1 termination '+str(signum))
    signal.signal(signal.SIGTERM,terminate);os.environ['PATH']='/usr/bin:/bin'
    samples=[];window=None;configuration_before=None;result=dict(status='INCONCLUSIVE',Tier1='NOT_RUN',decision='INCONCLUSIVE',performance='NOT_MEASURED',exclusive=False,interpretation=POLICY,assignment=a.run_assignment,robustness_prerecord_commit=ROBUSTNESS_PRERECORD_COMMIT,robustness_prerecord_sha=ROBUSTNESS_PRERECORD_SHA)
    def identities(full=False):
        for p,v in (dict(whole,**pins) if full else pins).items():assert sha(p)==v,'Identity changed: '+p
    try:
        window=supervisor.ObservedQuiet(out,a.cpu,a.sibling,a.run_assignment,10800)
        configuration_before=host_configuration(a.cpu,a.sibling);save(out/'host-configuration-before.json',configuration_before)
        save(out/'preexecution.json',dict(baseline=BASE,candidate=CAND,support_head=a.support_sha,assignment=a.run_assignment,tier0_manifest_sha=a.tier0_sha,tier0_audit_sha=a.tier0_audit_sha,runtime_sha=a.runtime_sha,hosted_audit_sha=a.hosted_audit_sha,prerecord_sha=a.prerecord_sha,pins=pins,whole_boundary_pins=whole,build='NOT_RUN',exclusive=False,interpretation=POLICY))
        for p in [Path(__file__),package/'support/server_tier1_supervisor.py',a.prerecord,a.tier0_audit,a.hosted_audit]:shutil.copyfile(p,out/p.name)
        for case in CASES:
            exact=int(case.rsplit('_',1)[1])
            for mode in MODES:
                reference=None
                for repeat in range(1,4):
                    for version in (['baseline','candidate'] if repeat%2 else ['candidate','baseline']):
                        label=f'{case}-{mode}-{repeat}-{version}';identities()
                        print('START '+label,flush=True)
                        command=window.run([binaries[version],'-v','-cpu-lim=180','-'+mode,t0/'frozen-package/inputs'/case],t0/version,195,label)
                        identities();rc=command['returncode'];text=(out/(label+'.stdout')).read_bytes().decode('utf8',errors='replace')
                        row=dict(case=case,mode=mode,repeat=repeat,version=version,elapsed_sec=command['elapsed_sec'],returncode=rc,command=command['argv'],science='PENDING',
                            measurement={key:command.get(key) for key in ['original_start_monotonic','popen_begin_monotonic','popen_return_monotonic','last_alive_lower_monotonic','exited_upper_monotonic','exit_interval_sec','observed_exit_interval_width_sec','rusage_children_before','rusage_children_after','rusage_children_delta','waited_child_cpu_sec','waited_child_measurement_complete','descriptive_elapsed_minus_cpu_sec','descriptive_cpu_over_elapsed']})
                        samples.append(row);save(out/'samples.json',samples)
                        if rc not in (0,1):raise science.ScienceError('Solver crash/invalid return: '+label)
                        semantic=incomplete_science(science,rc,text,exact) if rc==1 else science.app(rc,text,exact);row['semantic']=semantic;row['science']='PASS';save(out/'samples.json',samples)
                        if rc==1:raise RuntimeError('Genuine incomplete solve blocks timing filter: '+label)
                        science.need(reference is None or reference==semantic,'Per-case result semantics changed: '+label);reference=semantic
                        assert command['waited_child_measurement_complete'] is True,'Incomplete waited-child usage provenance'
                        assert all(v>=0 for v in command['rusage_children_delta'].values()),'Negative waited-child usage delta'
                        lo,hi=command['exit_interval_sec'];assert 0<=lo<=hi<=command['elapsed_sec'],'Invalid observed exit interval'
                        assert command['waited_child_cpu_sec']>0,'Unresolved CPU measurement'
                        row.update(exit_interval_sec=command['exit_interval_sec'],waited_child_cpu_sec=command['waited_child_cpu_sec']);save(out/'samples.json',samples)
        assert len(samples)==48
        numeric,reason,legacy_details=judge(samples,CASES);medians=[]
        for case in CASES:
            for mode in MODES:
                values={v:[r['elapsed_sec'] for r in samples if r['case']==case and r['mode']==mode and r['version']==v] for v in BINHASHES}
                b,c=[statistics.median(values[v]) for v in BINHASHES]
                medians.append(dict(case=case,mode=mode,raw=values,baseline_median=b,candidate_median=c,ratio=c/b,range_envelope=max(values['candidate'])/min(values['baseline']),nonoverlapping_regression=min(values['candidate'])>max(values['baseline'])))
        corroboration=robustness_details(samples,CASES)
        result.update(status='FILTER_COMPLETE',Tier1='48_SCIENCE_PASS',performance='OBSERVED_QUIET_DIAGNOSTIC',numeric_filter=numeric,numeric_reason=reason,legacy_filter_details=legacy_details,medians=medians,robustness_details=corroboration,
            preliminary_corroboration=(numeric=='pass' and all(r['corroborated'] for r in corroboration if r['mode']=='card-mto')),decision='INCONCLUSIVE',reason='Original numeric filter and preregistered corroboration reported separately; no Tier2/control/adoption claim')
    except science.ScienceError as error:
        result.update(status='SCIENTIFIC_REJECT',Tier1='REJECT',decision='REJECT',reason=str(error));print('SCIENCE STOP '+str(error),flush=True)
    except BaseException as error:result['reason']=repr(error)
    finally:
        if configuration_before is not None:
            try:
                configuration_after=host_configuration(a.cpu,a.sibling);save(out/'host-configuration-after.json',configuration_after)
                result['available_configuration_unchanged']=configuration_before==configuration_after
                result['unavailable_configuration_fields']=[k for k,v in configuration_after.items() if not v['available']]
            except BaseException as error:result.update(available_configuration_unchanged=False,configuration_error=repr(error))
        if window is not None:
            try:
                window.close();restoration=read(out/'restoration.json')
                assert restoration['confirmed'] is True and restoration['actual_affinity']==sorted(window.original),'Actual affinity restoration unconfirmed'
                result['cleanup_restoration_confirmed']=True
            except BaseException as error:result.update(cleanup_restoration_confirmed=False,cleanup_error=repr(error))
        try:identities(full=True);result['full_identity_confirmed']=True
        except BaseException as error:result.update(full_identity_confirmed=False,identity_error=repr(error))
        result['valid_run']=bool(result['status']=='FILTER_COMPLETE' and len(samples)==48 and result.get('cleanup_restoration_confirmed') and result.get('full_identity_confirmed'))
        result['engineering_corroboration_valid']=bool(result['valid_run'] and result.get('preliminary_corroboration') and result.get('available_configuration_unchanged'))
        result['engineering_status']='TIER1_CORROBORATED_TIER2_PENDING' if result['engineering_corroboration_valid'] else 'NUMERIC_PASS_WITH_ROBUSTNESS_UNRESOLVED' if result.get('numeric_filter')=='pass' else result.get('numeric_filter','INCONCLUSIVE')
        if not result['valid_run'] and result['decision']!='REJECT':result.update(status='INCONCLUSIVE',decision='INCONCLUSIVE')
        if out.exists():
            save(out/'result.json',result);save(out/'SHA256.json',{str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256.json'})
        print(json.dumps(result,indent=2),flush=True)
    return 0 if result.get('valid_run') else 1
if __name__=='__main__':sys.exit(main())
