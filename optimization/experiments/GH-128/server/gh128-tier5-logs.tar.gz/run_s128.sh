#!/bin/bash
# GH-128 S1 driver on yfclab2: Tier 5 (-p1skip=on, cores 0-51) and tier0-4 identity/correctness runs (cores 52-59).
cd ~/mac-agent-20261009/gh128-c84c891
R=../results/gh128-s1
echo "start $(date)" >> $R/driver.log
python3 $R/runner/s128_tier5.py --bin ../frozen/server-gh128-c84c891/distqldpc --cpus 0-51 --out $R/tier5 --tag on --flags=-p1skip=on --limit 21600 > $R/tier5.out 2>&1 &
python3 $R/runner/s128_runs.py --jobs $R/runner/server_jobs.jsonl --out $R/t04 --cpus 52-59 > $R/t04.out 2>&1 &
wait
echo "ALL_DONE $(date)" >> $R/driver.log
